﻿namespace P05.FootballTeamGenerator
{
    using Core;

    public class StartUp
    {
        public static void Main()
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
