﻿namespace MilitaryElite.Enumerations
{
    public enum MissionState
    {
        inProgress,
        Finished
    }
}
