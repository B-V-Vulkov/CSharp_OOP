﻿namespace MilitaryElite
{
    using Core;

    public static class StartUp
    {
        public static void Main()
        {
            ConsoleEngine consoleEngine = new ConsoleEngine();

            consoleEngine.Run();
        }
    }
}
