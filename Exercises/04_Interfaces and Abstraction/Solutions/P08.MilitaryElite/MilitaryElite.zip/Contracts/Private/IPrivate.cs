﻿namespace MilitaryElite.Contracts.Private
{
    public interface IPrivate : ISoldier
    {
        decimal Salary { get; }
    }
}
