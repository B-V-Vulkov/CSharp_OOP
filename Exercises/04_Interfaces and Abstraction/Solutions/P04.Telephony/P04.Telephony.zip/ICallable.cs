﻿namespace P04.Telephony
{
    public interface ICallable
    {
        string Call();
    }
}
