﻿namespace P06.BirthdayCelebrations
{
    public interface IBirthdateable
    {
        string Birthdate { get; }
    }
}
