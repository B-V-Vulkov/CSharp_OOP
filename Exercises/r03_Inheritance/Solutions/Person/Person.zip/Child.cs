﻿namespace Person
{
    class Child : Person
    {
        public Child(string name, int age) 
            : base(name, age)
        {
        }
    }
}
